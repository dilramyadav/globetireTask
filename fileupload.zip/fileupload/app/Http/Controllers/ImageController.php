<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class ImageController extends Controller
{
    public function index(){
        return view('image');
    }
    public function store(Request $request){

        $imageName= $request->file->getClientOriginalName();
        $request->file->move(public_path('upload'),$imageName);
        $img =url('upload/'.$imageName);        
        return response()->json(['uploaded'=>'Ok','initialPreview'=>[$img],'initialPreviewAsData'=>true,'initialPreviewConfig'=>['caption'=>$imageName,'url'=>'/image-delete','key'=>1, 'previewAsData'=>true]]);
        
        

    }

    public function destroy(Request $request){
        $data = $request->all(); 
          
        return  response()->json([$data]);            
       
    }
}
