<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <title>Image Upload</title>
        
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.min.css" crossorigin="anonymous">
    <link href="<?php echo e(URL::asset('css/fileinput.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" crossorigin="anonymous">
    <link href="<?php echo e(URL::asset('themes/explorer-fa5/theme.css')); ?>" media="all" rel="stylesheet" type="text/css"/>
	
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>	
    <script src="<?php echo e(URL::asset('js/plugins/buffer.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/plugins/filetype.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/plugins/piexif.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/plugins/sortable.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/fileinput.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/locales/fr.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/locales/es.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('themes/fa5/theme.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('themes/explorer-fa5/theme.js')); ?>" type="text/javascript"></script>
</head>
<body>
    <div class="container my-4">
        <h1>File Upload Used Krajee Plugin Integrated By Dilram Yadav
            
        </h1>
        
        <hr> 
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">        
        <input type="file" id="file-1" name="file" multiple class="file">
        <br>
    </div>
    </body>
    <script>
       
       
       $("#file-1").fileinput({
            theme: 'fa',
            uploadUrl: "/image-view",
            deleteUrl: "/image-delete",
            uploadExtraData: function() {
                return {
                    _token: $("input[name='_token']").val(),
                };
            },
            allowedFileExtensions: ['jpg', 'png', 'gif'],
            overwriteInitial: false,
            initialPreviewAsData: true,
            maxFileSize:2000,
            maxFilesNum: 10,
        });
    </script>
    </html>
<?php /**PATH C:\xampp\htdocs\fileupload\resources\views/image.blade.php ENDPATH**/ ?>